#include "scanner.hpp"

/* Public */

Scanner::Scanner(std::istream & stream) {
        read_input(stream);
    };

bool Scanner::has_next() {
    return not input_text.empty();
}

// Complete this method
token_ty Scanner::next() {
    return token_ty{};
}


/* Private */
void Scanner::read_input(std::istream & stream) {
   constexpr auto read_size = std::size_t{4096};
   stream.exceptions(std::ios_base::badbit);
   //auto out = std::string{};
   auto buf = std::string(read_size, '\0');
   while (stream.read(& buf[0], read_size)) {
       input_text.append(buf, 0, stream.gcount());
   }
   input_text.append(buf, 0, stream.gcount());
}

Scanner::position Scanner::end_position_of(std::string text) {
    if (text.length() == 0) {
        return current_position;
    }
    auto end_position = current_position;
    for (auto& i : text.substr(0, text.length()-1)) {
        if (i == '\n') {
            end_position.first++;
            end_position.second = 1;
        }
        else {
            end_position.second++;
        }
    }
    return end_position;
} // end_position_of


Scanner::position Scanner::position_after(std::string text) {
    auto new_position = current_position;
    for (auto& i : text) {
        if (i == '\n') {
            new_position.first++;
            new_position.second = 1;
        }
        else {
            new_position.second++;
        }
    }

    return new_position;
} // position_after

// Complete these methods

// Methods to process literal tokens
bool Scanner::process_int_lit   (std::smatch match, token_ty& token) {
    return true;
}

bool Scanner::process_float_lit (std::smatch match, token_ty& token) {
    return true;
}

bool Scanner::process_char_lit  (std::smatch match, token_ty& token) {
    return true;
}

bool Scanner::process_string_lit(std::smatch match, token_ty& token) {
    return true;
}

bool Scanner::process_bool_lit  (std::smatch match, token_ty& token) {
    return true;
}

template<typename TokenType>
bool Scanner::default_rule      (std::smatch match, token_ty& token) {
    return true;
}

bool Scanner::default_ignore    (std::smatch match, token_ty& token) {
    return true;
}